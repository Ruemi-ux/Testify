import os
import shutil
import tempfile
import subprocess
import json
from typing import Tuple, List, Dict, Any


def run(cmd: list, cwd: str | None = None, timeout: int = 1800) -> Tuple[int, str, str]:
    """
    Execute a command and return (returncode, stdout, stderr).
    """
    p = subprocess.Popen(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    out, err = p.communicate(timeout=timeout)
    return p.returncode, out, err


def temp_workdir(prefix: str = "sentrius") -> str:
    """
    Create a temporary working directory under /tmp/sentrius or specified base.
    """
    base = os.environ.get("SENTRIUS_TMP", "/tmp/sentrius")
    os.makedirs(base, exist_ok=True)
    d = tempfile.mkdtemp(prefix=f"{prefix}-", dir=base)
    return d


def cleanup(path: str) -> None:
    """
    Remove the given directory recursively.
    """
    if path and os.path.exists(path):
        shutil.rmtree(path, ignore_errors=True)


def safe_json_loads(s: str) -> Any:
    """
    Safely parse a JSON string, returning None on failure.
    """
    try:
        return json.loads(s)
    except Exception:
        return None


def docker_run(image: str, args: list, mounts: List[tuple] | None = None, workdir: str | None = None, env: Dict[str, str] | None = None, network: str | None = None) -> Tuple[int, str, str]:
    """
    Run a docker image with optional mount points, working directory, environment, and network.
    """
    cmd = ["docker", "run", "--rm"]
    if mounts:
        for host, cont in mounts:
            cmd += ["-v", f"{host}:{cont}"]
    if workdir:
        cmd += ["-w", workdir]
    if env:
        for k, v in env.items():
            cmd += ["-e", f"{k}={v}"]
    if network:
        cmd += ["--network", network]
    cmd += [image] + args
    return run(cmd)