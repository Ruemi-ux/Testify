import React, { useState } from 'react'
import { scanRepo, exportSplunk, notify } from './api'

type Finding = {
  tool: string
  severity: string
  rule_id?: string
  title: string
  description?: string
  file?: string
  line?: number
  metadata?: Record<string,any>
}

export default function App() {
  const [repo, setRepo] = useState('')
  const [branch, setBranch] = useState('main')
  const [token, setToken] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [error, setError] = useState<string|undefined>()

  const handleScan = async () => {
    setLoading(true)
    setError(undefined)
    try {
      const data = await scanRepo(repo || undefined, branch || 'main', undefined, token || undefined)
      setResult(data)
      if ((data?.stats?.by_severity?.high || 0) + (data?.stats?.by_severity?.critical || 0) > 0) {
        await notify(`High/Critical findings in ${data.repo} (${data.branch})`, 'critical')
      }
    } catch (e: any) {
      setError(e?.response?.data?.detail || e.message)
    } finally {
      setLoading(false)
    }
  }

  const handleExport = async () => {
    if (!result?.findings?.length) return
    await exportSplunk(result.findings)
    alert('Exported to Splunk (if configured).')
  }

  const sevBadge = (sev: string) => {
    const s = sev?.toLowerCase()
    const bg = s === 'critical' ? '#7f1d1d' : s === 'high' ? '#991b1b' : s === 'medium' ? '#a16207' : s === 'low' ? '#0f766e' : '#1f2937'
    return <span style={{background:bg, color:'#fff', padding:'2px 8px', borderRadius:999, fontSize:12, textTransform:'uppercase'}}>{sev}</span>
  }

  return (
    <div style={{fontFamily:'ui-sans-serif, system-ui, -apple-system', padding:24, maxWidth:1100, margin:'0 auto'}}>
      <h1 style={{fontSize:28, marginBottom:8}}>Sentrius Dashboard</h1>
      <p style={{color:'#6b7280', marginBottom:24}}>Trivy • Semgrep • Gitleaks • Splunk • Slack/Discord</p>

      <div style={{display:'grid', gap:12, gridTemplateColumns:'1fr 160px 1fr auto'}}>
        <input placeholder="Repository URL (https://... .git)" value={repo} onChange={e=>setRepo(e.target.value)} style={inputStyle}/>
        <input placeholder="branch" value={branch} onChange={e=>setBranch(e.target.value)} style={inputStyle}/>
        <input placeholder="Private Token (optional)" value={token} onChange={e=>setToken(e.target.value)} style={inputStyle}/>
        <button onClick={handleScan} disabled={loading} style={btnStyle}>{loading?'Scanning...':'Scan'}</button>
      </div>

      {error && <div style={{marginTop:16, background:'#fef2f2', color:'#991b1b', padding:12, border:'1px solid #fecaca', borderRadius:8}}>{error}</div>}

      {result && (
        <div style={{marginTop:24}}>
          <div style={{display:'flex', alignItems:'center', justifyContent:'space-between'}}>
            <h2 style={{fontSize:22}}>Results for <code>{result.repo}</code> ({result.branch})</h2>
            <button onClick={handleExport} style={{...btnStyle, background:'#1f2937'}}>Export to Splunk</button>
          </div>
          <div style={{display:'flex', gap:12, marginTop:12}}>
            {statCard('Total', result.stats?.total || 0)}
            {statCard('Critical', result.stats?.by_severity?.critical || 0)}
            {statCard('High', result.stats?.by_severity?.high || 0)}
            {statCard('Medium', result.stats?.by_severity?.medium || 0)}
            {statCard('Low', result.stats?.by_severity?.low || 0)}
          </div>

          <div style={{marginTop:16, border:'1px solid #e5e7eb', borderRadius:12, overflow:'hidden'}}>
            <table style={{width:'100%', borderCollapse:'collapse'}}>
              <thead style={{background:'#f9fafb'}}>
                <tr>
                  <th style={thStyle}>Tool</th>
                  <th style={thStyle}>Severity</th>
                  <th style={thStyle}>Title</th>
                  <th style={thStyle}>File:Line</th>
                  <th style={thStyle}>Rule</th>
                </tr>
              </thead>
              <tbody>
                {(result.findings as Finding[]).map((f, i) => (
                  <tr key={i} style={{borderTop:'1px solid #e5e7eb'}}>
                    <td style={tdStyle}>{f.tool}</td>
                    <td style={tdStyle}>{sevBadge(f.severity)}</td>
                    <td style={tdStyle}>
                      <div style={{fontWeight:600}}>{f.title}</div>
                      {f.description && <div style={{color:'#6b7280', fontSize:13}}>{String(f.description).slice(0,180)}</div>}
                    </td>
                    <td style={tdStyle}><code>{f.file}{f.line ? ':'+f.line : ''}</code></td>
                    <td style={tdStyle}>{f.rule_id}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}

const inputStyle: React.CSSProperties = { padding:10, border:'1px solid #e5e7eb', borderRadius:8 }
const btnStyle: React.CSSProperties = { padding:'10px 16px', background:'#0ea5e9', color:'#fff', border:'none', borderRadius:8, cursor:'pointer' }
const thStyle: React.CSSProperties = { textAlign:'left', padding:12, fontWeight:700, borderBottom:'1px solid #e5e7eb' }
const tdStyle: React.CSSProperties = { textAlign:'left', padding:12 }

function statCard(label:string, value:number) {
  return (
    <div style={{border:'1px solid #e5e7eb', borderRadius:12, padding:12, minWidth:120}}>
      <div style={{color:'#6b7280', fontSize:12}}>{label}</div>
      <div style={{fontSize:22, fontWeight:700}}>{value}</div>
    </div>
  )
}