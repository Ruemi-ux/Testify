import axios from 'axios'

const API_BASE = (import.meta as any).env.VITE_API_BASE || 'http://localhost:8000'

export async function scanRepo(repo_url?: string, branch: string = 'main', local_path?: string, private_token?: string) {
  const res = await axios.post(`${API_BASE}/scan`, { repo_url, branch, local_path, private_token })
  return res.data
}

export async function exportSplunk(findings: any[]) {
  const res = await axios.post(`${API_BASE}/export_splunk`, { findings })
  return res.data
}

export async function notify(message: string, level: 'info'|'warn'|'critical'='info') {
  const res = await axios.post(`${API_BASE}/notify`, { message, level })
  return res.data
}

export async function health() {
  const res = await axios.get(`${API_BASE}/health`)
  return res.data
}