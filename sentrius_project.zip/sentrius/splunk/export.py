import os
import requests
import time

SPLUNK_HEC_URL = os.environ.get("SPLUNK_HEC_URL")
SPLUNK_TOKEN = os.environ.get("SPLUNK_TOKEN")

def export_findings(findings, sourcetype="sentrius:findings", source="sentrius-backend"):
    if not SPLUNK_HEC_URL or not SPLUNK_TOKEN:
        return {"status": "skipped", "reason": "no splunk configured"}
    headers = {
        "Authorization": f"Splunk {SPLUNK_TOKEN}",
        "Content-Type": "application/json"
    }
    events = 0
    for f in findings:
        payload = {
            "time": int(time.time()),
            "sourcetype": sourcetype,
            "source": source,
            "event": f.model_dump()
        }
        r = requests.post(SPLUNK_HEC_URL, json=payload, headers=headers, timeout=20)
        r.raise_for_status()
        events += 1
    return {"status": "ok", "events": events}